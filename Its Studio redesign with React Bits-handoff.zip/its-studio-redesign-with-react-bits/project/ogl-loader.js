// ogl loader shared by React Bits components (esm.sh, no build step)
const OGL_URL = 'https://esm.sh/ogl@1.0.11';

let oglPromise = null;
export function loadOgl() {
  if (window.ogl) return Promise.resolve(window.ogl);
  if (oglPromise) return oglPromise;
  oglPromise = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.type = 'module';
    s.textContent =
      'import * as ogl from "' + OGL_URL + '";' +
      'window.ogl = ogl;' +
      'window.dispatchEvent(new Event("ogl:ready"));';
    const onReady = () => resolve(window.ogl);
    window.addEventListener('ogl:ready', onReady, { once: true });
    s.onerror = reject;
    document.head.appendChild(s);
    setTimeout(() => { if (!window.ogl) reject(new Error('ogl failed to load')); }, 15000);
  });
  return oglPromise;
}
