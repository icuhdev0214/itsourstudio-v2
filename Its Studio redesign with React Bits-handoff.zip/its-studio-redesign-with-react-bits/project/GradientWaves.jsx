// GradientWaves — React Bits (TS-CSS source ported to plain JSX; shaders unchanged)
const { useEffect, useRef } = React;

const hexToRgb = (hex) => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '');
  if (!result) return [1, 1, 1];
  return [parseInt(result[1], 16) / 255, parseInt(result[2], 16) / 255, parseInt(result[3], 16) / 255];
};
const detailToSteps = (detail) => (detail === 'low' ? 40.0 : detail === 'high' ? 110.0 : 70.0);
const num = (v, d) => (v === undefined || v === null || v === '' || isNaN(Number(v)) ? d : Number(v));
const bool = (v, d) => (v === undefined || v === null || v === '' ? d : v !== false && v !== 'false');

const vertex = `#version 300 es
in vec2 position;
void main() {
  gl_Position = vec4(position, 0.0, 1.0);
}
`;

const fragment = `#version 300 es
precision highp float;
uniform vec2 iResolution;
uniform float iTime;
uniform float uSpeed;
uniform float uAmplitude;
uniform float uWaveScale;
uniform float uWaveRatio;
uniform float uSwell;
uniform float uTurbulence;
uniform float uTilt;
uniform float uZoom;
uniform float uHeight;
uniform float uFogDepth;
uniform float uSteps;
uniform float uBrightness;
uniform float uOpacity;
uniform float uGrain;
uniform float uGrainIntensity;
uniform vec2 uMouse;
uniform float uParallax;
uniform bool uEnableMouse;
uniform vec3 uHorizonColor;
uniform vec3 uWaveColor;
uniform vec3 uCrestColor;
out vec4 fragColor;

const float MAX_DIST = 20000.0;

float hash21(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float plasma(vec3 r, vec2 freq, vec4 tc) {
  float mx = r.x + tc.x;
  mx += uSwell * sin((r.y + mx) / 20.0 + tc.y);
  float my = r.y - tc.z;
  my += uTurbulence * cos(r.x / 23.0 + tc.w);
  return r.z - (sin(mx * freq.x) * uAmplitude + sin(my * freq.y) * uAmplitude + uHeight);
}

float raymarch(vec3 pos, vec3 dir, vec2 freq, vec4 tc) {
  float dist = 0.0;
  for (int i = 0; i < 128; i++) {
    if (float(i) >= uSteps) break;
    float dscene = plasma(pos + dist * dir, freq, tc);
    if (abs(dscene) < 0.1) break;
    dist += 0.9 * dscene;
    if (!(abs(dist) < MAX_DIST)) return MAX_DIST;
  }
  return dist;
}

void main() {
  float T = iTime * uSpeed;
  vec2 freq = vec2(uWaveScale / 7.0, (uWaveScale * uWaveRatio) / 3.0);
  vec4 tc = vec4(T / 0.130, T / 0.810, T / 0.200, T / 0.710);
  float c, s;
  float vfov = (3.14159 / 2.3) / max(uZoom, 0.05);
  vec3 cam = vec3(0.0, 0.0, 30.0);
  vec2 uv = (gl_FragCoord.xy / iResolution.xy) - 0.5;
  uv.x *= iResolution.x / iResolution.y;
  uv.y *= -1.0;

  vec3 dir = vec3(0.0, 0.0, -1.0);
  float ulen = length(uv);
  float xrot = vfov * ulen;
  c = cos(xrot); s = sin(xrot);
  dir = mat3(1.0, 0.0, 0.0, 0.0, c, -s, 0.0, s, c) * dir;
  vec2 nuv = ulen > 1e-5 ? uv / ulen : vec2(1.0, 0.0);
  c = nuv.x; s = nuv.y;
  dir = mat3(c, -s, 0.0, s, c, 0.0, 0.0, 0.0, 1.0) * dir;
  c = cos(uTilt); s = sin(uTilt);
  dir = mat3(c, 0.0, s, 0.0, 1.0, 0.0, -s, 0.0, c) * dir;

  if (uEnableMouse) {
    float yaw = (uMouse.x - 0.5) * uParallax * 0.4;
    float pitch = (uMouse.y - 0.5) * uParallax * 0.4;
    c = cos(yaw); s = sin(yaw);
    dir = mat3(c, 0.0, s, 0.0, 1.0, 0.0, -s, 0.0, c) * dir;
    c = cos(pitch); s = sin(pitch);
    dir = mat3(1.0, 0.0, 0.0, 0.0, c, -s, 0.0, s, c) * dir;
  }

  float dist = raymarch(cam, dir, freq, tc);
  vec3 pos = cam + dist * dir;

  float t = clamp(uFogDepth / max(dist, 0.001), 0.0, 1.0);
  vec3 body = mix(uWaveColor, uCrestColor, clamp(pos.z * 0.08 + 0.5, 0.0, 1.0));
  vec3 col = mix(uHorizonColor, body, t);
  col *= uBrightness;
  col = clamp(col, 0.0, 1.0);

  float alpha = clamp(t, 0.0, 1.0) * uOpacity;
  if (uGrain > 0.5) {
    float g = hash21(gl_FragCoord.xy + mod(iTime, 64.0) * 11.0);
    alpha += (g - 0.5) * uGrainIntensity;
  }
  alpha = clamp(alpha, 0.0, 1.0);
  fragColor = vec4(col * alpha, alpha);
}
`;

function GradientWaves(props) {
  const {
    horizonColor = '#5227FF', waveColor = '#FF9FFC', crestColor = '#FFFFFF',
    speed = 0.4, amplitude = 2.5, waveScale = 0.6, waveRatio = 0.9,
    swell = 35, turbulence = 20, tilt = 1.11, zoom = 1.0, height = 5.5,
    fogDepth = 15, detail = 'medium', brightness = 1.0, opacity = 1.0,
    mouseInteraction = true, parallaxStrength = 0.5, grain = true, grainIntensity = 0.05,
    style
  } = props;

  const containerRef = useRef(null);
  const ctxRef = useRef(null);
  const enableMouseRef = useRef(bool(mouseInteraction, true));

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    let cleanup = () => {};
    let cancelled = false;

    import('./ogl-loader.js').then(m => m.loadOgl()).then(({ Renderer, Program, Mesh, Triangle }) => {
      if (cancelled) return;
      const renderer = new Renderer({
        webgl: 2, alpha: true, premultipliedAlpha: true, antialias: false,
        dpr: Math.min(window.devicePixelRatio || 1, 2)
      });
      const gl = renderer.gl;
      gl.clearColor(0, 0, 0, 0);
      const canvas = gl.canvas;
      canvas.style.width = '100%';
      canvas.style.height = '100%';
      canvas.style.display = 'block';
      container.appendChild(canvas);

      const geometry = new Triangle(gl);
      const program = new Program(gl, {
        vertex, fragment,
        uniforms: {
          iTime: { value: 0 },
          iResolution: { value: new Float32Array([1, 1]) },
          uSpeed: { value: 0.4 }, uAmplitude: { value: 2.5 }, uWaveScale: { value: 0.6 },
          uWaveRatio: { value: 0.9 }, uSwell: { value: 35 }, uTurbulence: { value: 20 },
          uTilt: { value: 1.11 }, uZoom: { value: 1.0 }, uHeight: { value: 5.5 },
          uFogDepth: { value: 15 }, uSteps: { value: 70.0 }, uBrightness: { value: 1.0 },
          uOpacity: { value: 1.0 }, uGrain: { value: 1.0 }, uGrainIntensity: { value: 0.05 },
          uMouse: { value: new Float32Array([0.5, 0.5]) }, uParallax: { value: 0.5 },
          uEnableMouse: { value: true },
          uHorizonColor: { value: new Float32Array([1, 1, 1]) },
          uWaveColor: { value: new Float32Array([1, 1, 1]) },
          uCrestColor: { value: new Float32Array([1, 1, 1]) }
        }
      });

      const mesh = new Mesh(gl, { geometry, program });
      ctxRef.current = { program };

      const setSize = () => {
        const rect = container.getBoundingClientRect();
        renderer.setSize(Math.max(1, Math.floor(rect.width)), Math.max(1, Math.floor(rect.height)));
        const res = program.uniforms.iResolution.value;
        res[0] = gl.drawingBufferWidth;
        res[1] = gl.drawingBufferHeight;
        renderer.render({ scene: mesh });
      };

      const ro = new ResizeObserver(setSize);
      ro.observe(container);
      setSize();

      const currentMouse = [0.5, 0.5];
      const targetMouse = [0.5, 0.5];
      const onPointerMove = (e) => {
        const rect = canvas.getBoundingClientRect();
        targetMouse[0] = (e.clientX - rect.left) / rect.width;
        targetMouse[1] = 1.0 - (e.clientY - rect.top) / rect.height;
      };
      const onPointerLeave = () => { targetMouse[0] = 0.5; targetMouse[1] = 0.5; };
      canvas.addEventListener('pointermove', onPointerMove);
      canvas.addEventListener('pointerleave', onPointerLeave);

      let raf = 0, isVisible = true, isPageVisible = !document.hidden;
      const t0 = performance.now();
      const loop = (t) => {
        program.uniforms.iTime.value = (t - t0) * 0.001;
        const tx = enableMouseRef.current ? targetMouse[0] : 0.5;
        const ty = enableMouseRef.current ? targetMouse[1] : 0.5;
        currentMouse[0] += 0.05 * (tx - currentMouse[0]);
        currentMouse[1] += 0.05 * (ty - currentMouse[1]);
        const m = program.uniforms.uMouse.value;
        m[0] = currentMouse[0]; m[1] = currentMouse[1];
        renderer.render({ scene: mesh });
        raf = requestAnimationFrame(loop);
      };
      const tryStart = () => { if (isVisible && isPageVisible && raf === 0) raf = requestAnimationFrame(loop); };
      const tryStop = () => { if (raf !== 0) { cancelAnimationFrame(raf); raf = 0; } };

      const io = new IntersectionObserver(([entry]) => {
        isVisible = entry.isIntersecting;
        isVisible ? tryStart() : tryStop();
      }, { threshold: 0 });
      io.observe(container);

      const onVisibility = () => {
        isPageVisible = !document.hidden;
        isPageVisible ? tryStart() : tryStop();
      };
      document.addEventListener('visibilitychange', onVisibility);
      tryStart();

      cleanup = () => {
        tryStop();
        ro.disconnect();
        io.disconnect();
        document.removeEventListener('visibilitychange', onVisibility);
        canvas.removeEventListener('pointermove', onPointerMove);
        canvas.removeEventListener('pointerleave', onPointerLeave);
        ctxRef.current = null;
        try { container.removeChild(canvas); } catch (e) {}
        const lose = gl.getExtension('WEBGL_lose_context');
        if (lose) lose.loseContext();
      };
    });

    return () => { cancelled = true; cleanup(); };
  }, []);

  useEffect(() => {
    const ctx = ctxRef.current;
    if (!ctx) return;
    const u = ctx.program.uniforms;
    enableMouseRef.current = bool(mouseInteraction, true);
    u.uSpeed.value = num(speed, 0.4);
    u.uAmplitude.value = num(amplitude, 2.5);
    u.uWaveScale.value = num(waveScale, 0.6);
    u.uWaveRatio.value = num(waveRatio, 0.9);
    u.uSwell.value = num(swell, 35);
    u.uTurbulence.value = num(turbulence, 20);
    u.uTilt.value = num(tilt, 1.11);
    u.uZoom.value = num(zoom, 1);
    u.uHeight.value = num(height, 5.5);
    u.uFogDepth.value = num(fogDepth, 15);
    u.uSteps.value = detailToSteps(detail);
    u.uBrightness.value = num(brightness, 1);
    u.uOpacity.value = num(opacity, 1);
    u.uGrain.value = bool(grain, true) ? 1.0 : 0.0;
    u.uGrainIntensity.value = num(grainIntensity, 0.05);
    u.uParallax.value = num(parallaxStrength, 0.5);
    u.uEnableMouse.value = bool(mouseInteraction, true);
    const set = (arr, hex) => { const v = hexToRgb(hex); arr[0] = v[0]; arr[1] = v[1]; arr[2] = v[2]; };
    set(u.uHorizonColor.value, horizonColor);
    set(u.uWaveColor.value, waveColor);
    set(u.uCrestColor.value, crestColor);
  });

  return <div ref={containerRef} style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden', ...(style || {}) }} />;
}

module.exports = { GradientWaves };
