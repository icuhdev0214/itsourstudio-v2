repo: icuhdev0214/itsourstudio-v2
branch: main

## Last sync

date: 2026-08-31T15:12:00Z

### Updated in this project

- Built a clickable prototype (Home / Gallery / Services + booking modal) from the repo's real packages, prices and copy.
- Imported the studio's real photos (gallery, about, logo) from `public/`.
- Booking flow mirrors the app: package → schedule → extension → details → 50% GCash downpayment → IOS reference.

## Screen map

| Screen | Built from |
| --- | --- |
| Its Our Studio Prototype.dc.html — Home | src/pages/Home.tsx, src/components/Navbar.tsx, src/components/Footer.tsx |
| Its Our Studio Prototype.dc.html — Gallery | src/pages/Gallery.tsx, public/gallery/* |
| Its Our Studio Prototype.dc.html — Services | src/pages/Services.tsx (DEFAULT_SERVICES) |
| Its Our Studio Prototype.dc.html — Booking modal | src/components/BookingModal.tsx, src/utils/payment.ts, src/utils/generateReference.ts |
| Its Our Studio.dc.html — redesign concept | Not repo-derived (React Bits exploration on the Organic design system) |
